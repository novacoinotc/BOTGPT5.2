"""
Trading Module  
Contiene componentes de paper trading
"""
