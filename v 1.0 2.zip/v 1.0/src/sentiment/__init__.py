"""
Sentiment Analysis Module
Analiza noticias, sentiment y fear & greed para mejorar decisiones de trading
"""
